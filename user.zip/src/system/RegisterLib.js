import AjaxFetch from './lib/AjaxFetch'
import StoreInit from './lib/StoreInit'
import CommonLib from './lib/CommonLib'

const RegisterLib = {
    ajax: AjaxFetch,
    store: StoreInit,
    common: CommonLib,
}


export default RegisterLib