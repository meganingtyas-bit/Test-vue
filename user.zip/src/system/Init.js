import RegisterLib from './RegisterLib'
const vueconfig = require('../../config')
class Init {

    mixin(Vue) {
        Vue.mixin({
            methods: {
                lib() {
                    return RegisterLib
                },
                config() {
                    return vueconfig.app;
                }
            }
        });
    }
}

export default new Init();