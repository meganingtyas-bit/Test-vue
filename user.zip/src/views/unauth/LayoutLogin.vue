<template>
  <v-row align="center" justify="center">
    <v-col cols="12" sm="7" md="5">
      <v-card flat>
        <v-card-title class="justify-center pb-2">Administrator</v-card-title>
        <v-form class="pa-3" @keyup.native.enter="save">
          <v-text-field
            outlined
            dense
            label="email"
            type="text"
            v-model="form.email"
            v-validate="'required'"
            data-vv-name="email"
            :error-messages="errors.collect('email')"
            required
          ></v-text-field>
          <v-text-field
            outlined
            dense
            label="Password"
            :type="show ? 'text' : 'password'"
            v-model="form.password"
            v-validate="'required|min:5|max:20'"
            data-vv-name="password"
            :counter="20"
            :error-messages="errors.collect('password')"
            :append-icon="show ? 'mdi-eye' : 'mdi-eye-off'"
            required
            @click:append="show = !show"
          ></v-text-field>
          <!-- <v-btn class="body-1 pa-0 primary--text text-capitalize" text to="/reset">Lupa Password</v-btn> -->
          <div class="text-center mt-5 mb-5">
            <v-alert type="error" text dense prominent v-show="response !== null">{{ response }}</v-alert>
            <v-btn
              color="primary white--text text-capitalize"
              block
              :loading="process.run"
              :disabled="process.run"
              @click="save"
            >Masuk</v-btn>
            
          </div>
          <v-btn
              color="warning white--text text-capitalize"
              block
              to="/register"
            >Register</v-btn>
        </v-form>
        <!-- <v-card-text class="body-1 text-center">
          <p>
            Belum menerima kode verifikasi ?
            <v-btn
              class="body-1 pa-0 primary--text text-capitalize"
              text
              to="/verification"
            >Kirim ulang</v-btn>
          </p>
          <p class="mb-0">
            Belum punya akun ?
            <v-btn class="body-1 primary--text text-capitalize" text to="/register">Daftar</v-btn>
          </p>
        </v-card-text> -->
      </v-card>
    </v-col>
  </v-row>
</template>

<script>
export default {
  $_veeValidate: {
    validator: "new"
  },
  data() {
    return {
      show: false,
      form: {
        email: null,
        password: null
      },
      dictionary: {
        custom: {
          email: {
            required: () => "email tidak boleh kosong"
          },
          password: {
            required: () => "Password tidak boleh kosong",
            min: "Minimal password 5 karakter",
            max: "Maksimal password 20 karakter"
          }
        }
      },
      process: {
        run: false
      },
      response: null
    };
  },
  head() {},
  components: {},
  mounted() {
    this.$validator.localize("en", this.dictionary);
  },
  methods: {
    async save() {
      this.response = null;
      const valid = await this.$validator.validateAll();
      if (valid) {
        this.process.run = true;
        this.axios
          .post(`https://reqres.in/api/login`,
           {
            email: this.form.email,
            password: this.form.password
           
          })
          .then(res => {
            console.log(res)
            if (res.status == 200) {
              this.$store.dispatch("user/setToken", res.data.token);
              //this.$store.dispatch("user/setUserData", res.data.data.profile);
              this.$router.push({ path: "/dashboard" });
            } else {
              this.process.run = false;
              // this.response = res.data.result.description;
              //this.$router.push({ name: "Dashboard" });
              
            }
          });
      } else {
        this.response = "Periksa kembali data yang anda masukkan";
      }
    }
  }
};
</script>

<style>
a:-webkit-any-link {
  text-decoration: none;
}
</style>
