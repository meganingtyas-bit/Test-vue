<template>
	<v-row align="center" justify="center">
		<v-col cols="12" sm="7" md="5">
			<v-card flat>
				<v-card-title class="justify-center pb-5">Register</v-card-title>
				<v-alert border="right" colored-border type="error" elevation="2">
					<p>
						Registrasi sementara ditutup, untuk lebih lanjut silahkan hubungi
						admin
					</p>
					<p>
						<v-btn
							class="body-1 primary--text text-capitalize"
							text
							to="/login"
						>
							kembali
						</v-btn>
					</p>
				</v-alert>
			</v-card>
		</v-col>
	</v-row>
</template>

<script>
export default {
	data() {
		return {};
	}
};
</script>
