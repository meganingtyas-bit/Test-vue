<template>
  <v-row
    align="center"
    justify="center">
    <v-col
      cols="12"
      sm="7"
      md="5">
      <v-card flat>
        <v-card-title class="justify-center pb-2">
          Daftar User
        </v-card-title>
        <v-form class="pa-3" @keyup.native.enter="save">
          <v-text-field
            outlined
            dense
            label="E-mail"
            type="email"
            v-model="form.email"
            v-validate="'required|email'"
            data-vv-name="email"
            :error-messages="errors.collect('email')"
            required>
          </v-text-field>
          <v-text-field
            outlined
            dense
            label="Password"
            :type="show.password ? 'text' : 'password'"
            v-model="form.password"
            v-validate="'required|min:8|max:20'"
            data-vv-name="password"
            :counter="20"
            :error-messages="errors.collect('password')"
            :append-icon="show.password ? 'mdi-eye' : 'mdi-eye-off'"
            ref="password"
            required
            @click:append="show.password = !show.password">
          </v-text-field>
          <div class="text-center mt-5">
            <v-alert 
              type="error" 
              text
              dense
              prominent
              v-show="response !== null">
              {{ response }}
            </v-alert>
            <v-btn 
              color="primary white--text text-capitalize"
              block
              :loading="process.run"
              :disabled="process.run"
              @click="save">
              Daftar
            </v-btn>
          </div>
        </v-form>
        <v-card-text class="body-1 text-center">
          Sudah punya akun ?
          <v-btn
            class="body-1 primary--text text-capitalize"
            text
            to="/login">
            Masuk
          </v-btn>
        </v-card-text>
        <v-dialog v-model="dialog.feedback" max-width="290">
      <v-card>
        <v-card-title class="headline"></v-card-title>
        <v-card-text>
          <v-icon large :color="feedback.iconColor">{{ feedback.icon }}</v-icon>
          {{ feedback.text }}
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="green darken-1" text @click="dialog.feedback = false">OK</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
      </v-card>
    </v-col>
  </v-row>
</template>

<script>
  export default {
    $_veeValidate: {
      validator: 'new'
    },
    data () {
      return {
        show: {
          password: false
        },
        form: {
          email: '',
          password: ''
        },
        dictionary: {
          custom: {
            
            email: {
              required: () => 'E-mail tidak boleh kosong',
              email: 'Format email belum benar'
            },
            password: {
              required: () => 'Password tidak boleh kosong',
              min: 'Minimal password 8 karakter',
              max: 'Maksimal password 20 karakter'
            }
          }
        },
        process: {
          run: false
        },
        dialog:{
          feedback:false
        },
        feedback: {
        text: "",
        icon: "",
        iconColor: ""
      },
        response: null
      }
    },
    head () {
      
    },
    components: {
      
    },
    mounted () {
      this.$validator.localize('en', this.dictionary)
    },
    methods: {
      async save () {
        this.response = null
        const valid = await this.$validator.validateAll()
        if (valid) {
        this.process.run = true;
        this.axios
          .post(`https://reqres.in/api/register`,
           {
            email: this.form.email,
            password: this.form.password          
          })
          .then(res => {
            console.log(res)
            if (res.status == 200) {
              alert('Sukses Register')
              this.alert("success",'Sukses register data');

              this.$store.dispatch("user/setToken", res.data.token);
              //this.$store.dispatch("user/setUserData", res.data.data.profile);
              this.$router.push({ path: "/login" });

            } else {
              this.process.run = false;
              console.log(res)
              // this.response = res.data.result.description;
              //this.$router.push({ name: "Dashboard" });
              
            }
          });
        } else {
          this.response = 'Periksa kembali data yang anda masukkan'
        }
      },
      alert(type, msg) {
      this.dialog.feedback = true;
      this.feedback.text = msg;

      switch (type) {
        case "success":
          this.feedback.icon = "mdi-check-circle";
          this.feedback.iconColor = "green darken-1";
          break;
        case "failed":
          this.feedback.icon = "mdi-message-alert";
          this.feedback.iconColor = "yellow darken-1";
          break;
        case "error":
          this.feedback.icon = "mdi-alert";
          this.feedback.iconColor = "deep-orange darken-1";
          break;
      }
    }
  }
}
</script>
