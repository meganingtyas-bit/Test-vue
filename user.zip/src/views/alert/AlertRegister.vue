<template>
  <div>
    <div class="boxAlert">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-xs-12 text-center">
            <div>
              <div>
                <img
                  v-bind:src="require(`@/assets/images/${message[type].image}`)"
                  class="imgChecked"
                  width="100%"
                />
              </div>
              <div class="h-Aktivasi">
                <h4 :class="message[type].class">{{message[type].title}}</h4>
              </div>
              <div class="pAktivasi text-center">
                <p>{{message[type].description}}</p>
              </div>
              <div class="button-Aktivasi">
                <button class="btn-Aktivasi">{{message[type].tombol}}</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "AlertRegister",
  props: ["type"],
  data() {
    return {
      message: {
        success: {
          title: "Aktivasi Berhasil",
          description:
            "Akun anda berhasil terverifikasi. Silahkan lakukan pendaftaran kembali melalui tombol dibawah ini.",
          image: "checked.png",
          tombol: "Kembali Masuk",
          class: "blue"
        },
        error: {
          title: "Aktivasi Gagal",
          description:
            "Akun anda gagal terverifikasi. Silahkan lakukan pendaftaran kembali melalui tombol dibawah ini.",
          image: "cancel.png",
          tombol: "Daftar Kembali",
          class: "red"
        }
      },
      form: {
        email: "",
        password: ""
      },
      show: true
    };
  },
  methods: {
    onSubmit(evt) {
      evt.preventDefault();
      alert(JSON.stringify(this.form));
    },
    goRegistrasi() {
      this.$router.push({ name: "AuthRegister" });
    },
    goForgot() {
      this.$router.push({ name: "AuthForgotPassword" });
    },
    onReset(evt) {
      evt.preventDefault();
      // Reset our form values
      this.form.email = "";
      this.form.password = "";
      // Trick to reset/clear native browser form validation state
      this.show = false;
      this.$nextTick(() => {
        this.show = true;
      });
    },
    created() {
  

      // console.log('sssssssssssssssssssssss')
      console.log(this.lib.store.get("user"));
    }
  }
};
</script>

<style>
.blue {
  color: dodgerblue;
}

.red {
  color: red;
}
</style>