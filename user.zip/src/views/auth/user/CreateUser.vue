<template>
  <div id="box-create">
    <v-breadcrumbs :items="breadcrumb" divider=">" class="pa-3 c-default"></v-breadcrumbs>
    <!-- <v-list-item-title class="headline page_title">Company</v-list-item-title> -->
    <v-alert
      type="error"
      text
      dense
      prominent
      v-show="feedback.status && feedback.textHTML"
      v-html="feedback.textHTML"
    ></v-alert>
    <v-alert
      type="error"
      text
      dense
      prominent
      v-show="feedback.status && feedback.text"
    >{{ feedback.text }}</v-alert>
    <v-form id="form-create">
      <v-card outlined class="pa-3">
        <v-row>
          <v-col cols="12" md="8" lg="9">
            <v-text-field
              outlined
              dense
              label="Nama Depan"
              type="text"
              v-model="form.first_name"
              v-validate="'required'"
              data-vv-name="Nama Depan"
              :error-messages="errors.collect('Nama Depan')"
              required
            ></v-text-field>
            <v-text-field
              outlined
              dense
              label="Nama Akhir"
              type="text"
              v-model="form.last_name"
              v-validate="'required'"
              data-vv-name="Nama Akhir"
              :error-messages="errors.collect('Nama Akhir')"
              required
            ></v-text-field>
            <v-text-field
              outlined
              dense
              label="Email"
              type="email"
              v-model="form.email"
              v-validate="'required'"
              data-vv-name="Email"
              :error-messages="errors.collect('Email')"
              required
            ></v-text-field>
          </v-col>
          <v-col cols="12" md="4" lg="3" xl="2">
            <v-card outlined>
              <div class="box-title">
                <v-label>Avatar</v-label>
              </div>
              <div class="box-content">
                <image-input class="box-img-upload-c" v-model="images">
                  <div slot="activator">
                    <v-avatar
                      tile
                      size="200px"
                      height="250"
                      class="grey lighten-3 mb-5"
                      v-ripple
                      v-if="images.length < 1"
                    >
                      <v-icon color="grey darken-3" large>mdi-camera</v-icon>
                    </v-avatar>
                    <v-avatar v-else tile height="250" size="200px" class="mb-5" v-ripple>
                      <img :src="form.avatar" />
                    </v-avatar>
                  </div>
                </image-input>
              </div>
            </v-card>
          </v-col>
        </v-row>
      </v-card>
    </v-form>
    <div class="text-center pt-1 pb-1">
      <v-btn
        class="text-capitalize ma-1 border-outline-gradient"
        :disabled="process.loading"
        to="/category"
      >Batal</v-btn>
      <v-btn
        class="text-capitalize ma-1 bg-theme-gradient"
        :disabled="process.loading"
        :loading="process.loading"
        @click="save"
      >Simpan</v-btn>
    </div>
  </div>
</template>

<script>
import ImageInput from "@/components/ImageInput.vue";
export default {
  components: {
    ImageInput
  },
  data() {
    return {
      breadcrumb: [
        {
          text: "User",
          disabled: true,
          href: "/user"
        },
        {
          text: "Tambah",
          disabled: true,
          href: "#"
        }
      ],
      form:{
        first_name:'',
        last_name:'',
        email:'',
        avatar:''
      },
      images: "",
      process: {
        loading: false
      },
      feedback: {
        status: false,
        text: "",
        textHTML: ""
      },
      error: {
        detail: ""
      }
    };
  },
  mounted() {
    this.$validator.localize("en", this.dictionary);
  },
  watch:{
    images: {
      handler: function() {
        this.form.avatar = this.images.url;
      }
    }
  },
  methods: {
    validation() {
      let form = this.form,
        error = this.error,
        valid = true;

      if (form.first_name === "") {
        error.first_name = "Nama Depan tidak boleh kosong";
        valid = false;
      }
      if (form.last_name === "") {
        error.last_name = "Nama Akhir tidak boleh kosong";
        valid = false;
      }
      if (form.email === "") {
        error.email = "Email tidak boleh kosong";
        valid = false;
      }  else {
        error.first_name=null
        error.last_name=null
        error.email=null
      }

      return valid;
    },
    async save() {
      let self = this;
      let valids = this.validation();
      const valid = await this.$validator.validateAll();
      if (valids && valid) {
        this.response = null;
        this.process.run = true;
        // let formData = Object.assign({}, this.tambah);
        this.axios
          .post("https://reqres.in/api/users",
            {
              first_name:this.form.first_name,
              last_name:this.form.last_name,
              email:this.form.email,
              avatar:this.form.avatar
            })
          .then(response => {
            console.log(response)
            let res = response.data;
            if (response.status == 201) {
              alert('Sukses Input Data')
              this.$router.push({ path: "/user" });
            } else {
              this.process.run = false;
              // this.response = res.result.description;
            }
          });
      } else {
        this.response = "Periksa kembali data yang anda masukkan";
      }
    }
  }
};
</script>