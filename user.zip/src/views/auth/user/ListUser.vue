<template>
  <v-card>
    <v-card-title>
      <v-btn class="text-capitalize" color="error" to="/user/create">Add Data</v-btn>
      <v-spacer></v-spacer>
      <v-text-field
        v-model="params.search.value"
        append-icon="search"
        label="Pencarian..."
        single-line
        hide-details
        @keydown.enter.prevent="runSearch"
      ></v-text-field>

    </v-card-title>
    <v-data-table
      :headers="headers"
      :items="clientku"
      no-data-text="Belum ada data"
      no-results-text="Data tidak ditemukan"
      item-key="id"
      :options.sync="options"
      :loading="loading"
      :server-items-length="totalClient"
      :items-per-page="6"
      :footer-props="{'items-per-page-options': [6, 12, 18]}"
    >
      <template v-if="clientku" v-slot:item.button="{ item }">
        <v-tooltip bottom>
          <template v-slot:activator="{ on }">
            <v-btn
              v-on="on"
              class="ma-1"
              color="blue"
              fab
              x-small
              @click.stop="dialog.detail = true; detail = item;"
            >
              <v-icon>mdi-window-restore</v-icon>
            </v-btn>
          </template>
          <span>Detail User</span>
        </v-tooltip>
        <v-tooltip bottom>
          <template v-slot:activator="{ on }">
            <v-btn
              v-on="on"
              class="ma-1"
              color="purple"
              fab
              x-small
              :to="`/user/edit/`+item.id"
            >
              <v-icon>mdi-pencil</v-icon>
            </v-btn>
          </template>
          <span>Ubah User</span>
        </v-tooltip>
        <v-tooltip bottom>
          <template v-slot:activator="{ on }">
            <v-btn
              v-on="on"
              class="ma-1"
              color="pink"
              fab
              x-small
              @click.stop="hapus.id = item.id; hapus.title = item.first_name; dialog.hapus = true"
            >
              <v-icon>mdi-delete</v-icon>
            </v-btn>
          </template>
          <span>Hapus User</span>
        </v-tooltip>
      </template>
    </v-data-table>
    <v-row justify="center">
      <v-dialog v-model="dialog.detail" max-width="650">
        <v-card>
          <v-card-title
            class="headline"
          >Detail User {{ detail.first_name }} </v-card-title>
          <v-card-text>
            <v-simple-table class="detail-table">
              <template v-slot:default>
                <tbody>
                  <tr>
                    <td>
                      <strong>Nama Depan</strong>
                    </td>
                    <td>{{ detail.first_name }}</td>
                  </tr>
                  <tr>
                    <td>
                      <strong>Nama Belakang</strong>
                    </td>
                    <td>{{ detail.last_name }}</td>
                  </tr>
                  <tr>
                    <td>
                      <strong>Email</strong>
                    </td>
                    <td>{{ detail.email }}</td>
                  </tr>
                  <tr>
                    <td width="30%">
                      <strong>Avatar</strong>
                    </td>
                    <td>
                      <img
                        :src="detail.avatar"
                        alt
                        height="300px"
                        width="150px"
                        style="padding-top:8px; object-fit: cover; max-height: 80px;"
                      />
                    </td>
                  </tr>
                  
                </tbody>
              </template>
            </v-simple-table>
          </v-card-text>
          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn color="grey darken-1" text @click="dialog.detail = false">Tutup</v-btn>
          </v-card-actions>
        </v-card>
      </v-dialog>
      <v-dialog  v-model="dialog.hapus" max-width="450">
        <v-card id="dl-hapus">
          <v-card-title class="headline">Konfirmasi Hapus User</v-card-title>
          <v-card-text class="c-default">
            Apakah Anda yakin akan menghapus user
            <strong>{{ hapus.title }}</strong> ?
          </v-card-text>
          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn color="green darken-1" text @click="deletes">
              <v-progress-circular indeterminate color="primary" v-if="loading"></v-progress-circular>Hapus
            </v-btn>
            <v-btn color="red darken-1" text @click="dialog.hapus = false">Batal</v-btn>
          </v-card-actions>
        </v-card>
      </v-dialog>
    </v-row>
    <v-dialog v-model="dialog.feedback" max-width="290">
      <v-card>
        <v-card-title class="headline"></v-card-title>
        <v-card-text>
          <v-icon large :color="feedback.iconColor">{{ feedback.icon }}</v-icon>
          {{ feedback.text }}
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="green darken-1" text @click="dialog.feedback = false">OK</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-card>
</template>

<script>
import moment from "moment";
export default {
  data() {
    return {
      clientku:[],
      totalClient: 0,
      loading: false,
      options: {},
      params: {
        page: 1,
        per_page: 6,
        search: {
          field:
            "id::first_name::last_name",
          value: ""
        },
        filter: [
          {
            type: "numeric",
            field: "id",
            value: 1,
            comparison: "="
          }
        ]
      },
      headers: [
        {
          text: "ID",
          align: "left",
          sortable: true,
          value: "id"
        },
        {
          text: "Email",
          align: "left",
          sortable: true,
          value: "email"
        },
        {
          text: "First Name",
          align: "left",
          sortable: true,
          value: "first_name"
        },
        {
          text: "Aksi",
          align: "center",
          sortable: true,
          value: "button"
        },
      ],
      dialog: {
        detail: false,
        hapus:false,
        feedback: false
      },
      hapus:{
        id: 0,
        first_name: ""
      },
      detail: {},
      feedback: {
        text: "",
        icon: "",
        iconColor: ""
      }
    };
  },
  watch: {
    options: {
      handler() {
        this.getData();
      },
      deep: true
    },
    "$route.query"() {
      this.getData();
    }
  },
  mounted() {
    this.params.search.value = this.$route.query.search;
  },
  methods: {
    runSearch() {
      let dataQuery = {};

      if (this.params.search.value) {
        dataQuery.search = this.params.search.value;
        console.log(dataQuery.search);
        this.$router.push({
          path: "user",
          query: dataQuery
        }).catch(err => {console.log(err)});
      }
      this.getData();
    },
    getData() {
      this.loading = true;
      let sort = "";
      if (this.options.sortDesc[0] != true) {
        sort = "ASC";
      } else {
        sort = "DESC";
      }
      let params = {
        page: this.options.page,
        per_page: this.options.itemsPerPage,
        search: this.params.search.value
        //filter: this.params.filter
      };
      console.log(params);
      this.axios
        .get("https://reqres.in/api/users", { params })
        .then(response => {
          let res = response.data;
          if (response.status == 200) {
            this.loading = false;
            this.clientku = res.data;
            this.totalClient = res.total;
          }
          if (response.status === 400) {
            if (res.error_code == "error_validation") {
            }
            if (res.error_code == "error_failed") {
              this.alert("failed", res.msg);
            }
          }
          if (res.status === 401) {
          }
        });
    },
    async deletes() {
      // console.log(this.hapus.id)
      this.axios
        .delete("https://reqres.in/api/users", {
          id: this.hapus.id
        })
        .then(response => {
          let res = response.data;
          console.log(response)
          if (response.status == 204) {
            this.dialog.hapus = false;
            this.alert("success",'Sukses hapus data');
            this.getData()
          }

          if (response.status == 400) {
            if (res.error_code == "error_failed") {
              this.alert("failed", res.msg);
            }
          }

          if (res.status == 401) {
          }

          // console.log(res);
        });
    },
    alert(type, msg) {
      this.dialog.feedback = true;
      this.feedback.text = msg;

      switch (type) {
        case "success":
          this.feedback.icon = "mdi-check-circle";
          this.feedback.iconColor = "green darken-1";
          break;
        case "failed":
          this.feedback.icon = "mdi-message-alert";
          this.feedback.iconColor = "yellow darken-1";
          break;
        case "error":
          this.feedback.icon = "mdi-alert";
          this.feedback.iconColor = "deep-orange darken-1";
          break;
      }
    }
  }
};
</script>

<style scoped>
.detail-table tbody tr td {
  border-bottom: none !important;
}
</style>