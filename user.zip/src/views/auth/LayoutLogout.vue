<template>
	<div></div>
</template>

<script>
export default {
	name: "LayoutLogout",
	created() {
		this.$store.dispatch("user/resetUser");
		this.$router.push({ path: "login" });
	}
};
</script>
