<template>
  <div>Selamat datang Administrator</div>
</template>

<script>
export default {
  name: "LayoutDashboard",
  mounted() {}
};
</script>
