import StoreInit from "@/system/lib/StoreInit.js";
export default {
	namespaced: true,
	state: {
		logedIn: false,
		userData: {},
		token: ""
	},
	mutations: {
		SET_TOKEN(state, data) {
			state.token = data;
		},
		SET_USER(state, data) {
			state.userData = data;
			state.logedIn = true;
		},
		RESET_USER(state) {
			state.userData = {};
			state.logedIn = false;
			state.token = "";
		}
	},
	actions: {
		async setToken({ commit }, data) {
			commit("SET_TOKEN", data);
			StoreInit.set("token", data);
		},
		async setUserData({ commit }, data) {
			commit("SET_USER", data);
			StoreInit.setUserdata(data);
		},
		async resetUser({ commit }, data) {
			commit("RESET_USER");
			StoreInit.remove("token");
			StoreInit.removeUserdata();
		}
	}
};
