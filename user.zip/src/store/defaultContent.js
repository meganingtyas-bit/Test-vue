const detailCompany = {
	name: "",
	address: "",
	cp_name: "",
	cp_email:"",
	cp_mobilephone:"",
	cp_phone:"",
	package_name:"platinum",
	logo_url:"",
	detail:"",
	province_id:0,
	city_id:0,
	province_name:"",
	city_name:""

};

const detailEdit = {
	company_id:"",
	name: "",
	address: "",
	cp_name: "",
	cp_email:"",
	cp_mobilephone:"",
	cp_phone:"",
	logo_url:"",
	detail:"",
	province_id:0,
	city_id:0,
	province_name:"",
	city_name:""
};
export default {
	namespaced: true,
	state: {
		detailCompany: detailCompany,
		detailEdit: detailEdit

	},
	mutations: {},
	actions: {}
};
