import Vue from "vue";
import Vuex from "vuex";
Vue.use(Vuex);
//ddd

import defaultContent from "@/store/defaultContent.js";
import user from "@/store/user.js";

export default new Vuex.Store({
	state: {},
	mutations: {},
	actions: {},
	modules: {
		defaultContent,
		user
	}
});
