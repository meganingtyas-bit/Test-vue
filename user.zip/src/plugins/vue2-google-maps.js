import Vue from 'vue'
import * as VueGoogleMaps from 'vue2-google-maps'

Vue.use(VueGoogleMaps, {
	load: {
		key: 'AIzaSyApkJD-vBesPqZOKxrlrQw9puH852wp1n4',
		libraries: 'places',
		region: 'ID',
		language: 'id',
	},
	installComponents: true
})
