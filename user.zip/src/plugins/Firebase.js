// /plugins/firebase.js
// import Vue from "vue";
import * as firebase from "firebase/app";
// import 'firebase/auth'
// import 'firebase/firestore'
// import 'firebase/database'

var config = {
	apiKey: "AIzaSyCSiPRXrnEnvPOXn6DLDK_YwjlBekCKsa0",
	authDomain: "property-2019.firebaseapp.com",
	databaseURL: "https://property-2019.firebaseio.com",
	projectId: "property-2019",
	storageBucket: "property-2019.appspot.com",
	messagingSenderId: "939201037553",
	appId: "1:939201037553:web:96b8a7544668e181909550"
};

!firebase.apps.length ? firebase.initializeApp(config) : "";
// export const GoogleProvider = new firebase.auth.GoogleAuthProvider()
// export const auth = firebase.auth()
// export const DB = firebase.database()
// export const StoreDB = firebase.firestore()
// Vue.use(firebase);

export default firebase;
