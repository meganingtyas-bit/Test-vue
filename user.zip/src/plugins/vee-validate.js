import Vue from 'vue'
import * as VeeValidate from 'vee-validate'

Vue.use(VeeValidate)

export default VeeValidate
