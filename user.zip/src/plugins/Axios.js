import vueconfig from "../../config";
import Vue from "vue";
import axios from "axios";
import store from "@/store";
import VueAxios from "vue-axios";
import StoreInit from "@/system/lib/StoreInit.js";
import qs from "qs";

axios.defaults.timeout = 60 * 1 * 1000;
axios.defaults.paramsSerializer = function(params) {
	return qs.stringify(params);
};
axios.defaults.baseURL = vueconfig.apiBaseUrl;

async function setTokenNUserData(tokenLS = null, userdata = null) {
	userdata = StoreInit.getUserdata();
	tokenLS = StoreInit.get("token");
	if (tokenLS) {
		await store.dispatch("user/setToken", tokenLS);
	}
	if (store.state.user.token) {
		axios.defaults.headers.common["token"] = store.state.user.token;
		await store.dispatch("user/setUserData", userdata);
	}
}

setTokenNUserData();

// Add a request interceptor
axios.interceptors.request.use(
	async function(config) {
		setTokenNUserData();

		let headers = config.headers;
		if (store.state.user.token) {
			config.headers = Object.assign({}, headers, {
				token: store.state.user.token
			});
		}
		let param = config.params;
		config.params = Object.assign({}, param);
		// Do something before request is sent
		return config;
	},
	async function(error) {
		// Do something with request error
		return Promise.reject(error);
	}
);

// Add a response interceptor
axios.interceptors.response.use(
	async function(response) {
		// Any status code that lie within the range of 2xx cause this function to trigger
		// Do something with response data
		if (typeof response.data != "undefined") {
			if (response.data.status === 401) {
				if (response.data.error_code === "error_auth") {
					await store.dispatch("user/resetUser");
				}
			}
		}
		return response;
	},
	async function(error) {
		// Any status codes that falls outside the range of 2xx cause this function to trigger
		// Do something with response error

		return Promise.reject(error);
	}
);

Vue.use(VueAxios, axios);
/* ---------------------------------- */

export default axios;
