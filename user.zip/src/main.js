// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from "vue";

import App from "./App";
import router from "@/router";
import store from "@/store";

import StoreInit from "@/system/lib/StoreInit.js";
import Init from "@/system/Init";
import vuetify from "@/plugins/vuetify"; // path to vuetify export
import VeeValidate from "@/plugins/vee-validate";
import VueQuillEditor from "@/plugins/vue-quill-editor";
import Vue2GoogleMaps from "@/plugins/vue2-google-maps";
import Axios from "@/plugins/Axios";
import money from "v-money";
import './registerServiceWorker'

/* =========== AUTH ================ */
let userdata = StoreInit.getUserdata();
let tokenLS = StoreInit.get("token");
if (tokenLS) {
	store.dispatch("user/setToken", tokenLS);
	store.dispatch("user/setUserData", userdata);
}

/* =========== OTHER REGISTER VUE ================ */

// register directive v-money and component <money>
Vue.use(money, {
	precision: 4
});

/* ---------------------------------- */

/*  */
Vue.config.productionTip = false;
Init.mixin(Vue);
/* eslint-disable no-new */

new Vue({
	Axios,
	router,
	store,
	vuetify,
	VeeValidate,
	VueQuillEditor,
	Vue2GoogleMaps,
	watch: {
		"store.state.user.userData"(to, from) {
			store.dispatch("user/setUserData", user.state.user.userData);
			// Code
		}
	},
	render: h => h(App)
}).$mount("#app");
