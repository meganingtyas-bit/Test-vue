<template>
  <div id="app">
    <component v-bind:is="getTemplate" />
  </div>
</template>

<script>


export default {
  name: "App",
  data() {
    return {
      getLayout: ""
    };
  },
  computed: {
    getTemplate() {
      this.getLayout = this.$route.meta.layout;
      return this.getLayout;
    }
  },
  mounted() {
    
  },
  watch: {
    "$store.state.user.logedIn"(newVal, oldVal) {
      this.checkTokenFirebase(newVal);
    },
    $route(to, from) {
      window.scrollTo(0, 0);
    }
  },
  methods: {

  }
};
</script>
<style>
@import "assets/css/style.css";
</style>
