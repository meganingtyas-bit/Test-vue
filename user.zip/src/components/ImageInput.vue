<template>
    <div>
        <div class="container-image-upload" @click="launchFile()">
            <slot name="activator"></slot>
        </div>
        <input
            type="file"
            ref="file"
            :name="filename"
            v-on:change="changeImage($event.target.files)"
            style="display:none"
        />
        <v-dialog v-model="dialog">
            <v-card class="pa-0 ma-0" flat>
                <v-card color="red accent-2">
                    <v-list-item>
                        <v-list-item-avatar color="red accent-2" size="30">
                            <v-icon color="white" large>mdi-alert</v-icon>
                        </v-list-item-avatar>
                        <v-list-item-content>
                            <v-card-text class="caption white--text pa-0">{{ response }}</v-card-text>
                        </v-list-item-content>
                    </v-list-item>
                </v-card>
            </v-card>
        </v-dialog>
    </div>
</template>

<script>
export default {
    name: "image-input",
    data: () => ({
        dialog: false,
        filename: "file",
        response: null
    }),
    props: {
        // Use "value" to enable using v-model
        value: ""
    },
    methods: {
        launchFile() {
            this.$refs.file.click();
        },
        async changeImage(file) {
            let image = file[0];
            if (file.length > 0) {
                if (!image.type.match("image.*")) {
                    this.dialog = true;
                    this.response =
                        "Silahakan pilih gambar dengan format .jpg/.jpeg/.png";
                } else if (image.size > 1048576) {
                    this.dialog = true;
                    this.response = "Maksimal gambar 1MB";
                } else {
                    let formData = new FormData();
                    formData.append(
                        "key",
                        "59e51e5db668184d8c4a085fb8389c3acfd76a50"
                    );
                    formData.append("file", image);

                    fetch(`https://cdn.esd.co.id/image`, {
                        method: "POST",
                        body: formData
                    })
                        .then(res => res.json())
                        .then(respon => {
                            this.$emit("input", {
                                filename: image.name,
                                url: respon.data[0].original,
                                urlThumb: respon.data[0].thumb
                            });
                        });
                }
            }
        }
    }
};
</script>

<style scoped>
.container-image-upload {
    width: fit-content;
}
</style>