<template>
  <div id="tblank">
    <!-- ROUTER VIEW -->
    <router-view />
    <!-- ./ROUTER VIEW -->
  </div>
</template>

<script>
export default {
  name: "TemplateBlank",
  data: () => ({})
};
</script>
