<template>
  <v-app id="lrr">
    <v-content>
      <v-container>
        <!-- ROUTER VIEW -->
        <router-view />
        <!-- ./ROUTER VIEW -->
      </v-container>
    </v-content>
  </v-app>
</template>

<script>
export default {
  name: "LoginRegisterTemplate",
  props: {
    source: String
  },
  data: () => ({
    drawer: null
  })
};
</script>
