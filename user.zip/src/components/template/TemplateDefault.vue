<template>
  <v-app id="inspire">
    <v-navigation-drawer v-model="drawer" app>
      <v-list-item to="/profile">
        <v-list-item-avatar>
          <v-img :src="profile.image_url"></v-img>
        </v-list-item-avatar>

        <v-list-item-content>
          <v-list-item-title class="c-default text-left">User</v-list-item-title>
        </v-list-item-content>
      </v-list-item>

      <v-divider></v-divider>

      <v-list dense id="sidebar">
        <v-list-item-group v-model="active">
          <v-list-item v-for="(l, index) in navigation" :key="index" :to="l.action">
            <v-list-item-icon>
              <v-icon v-text="l.icon"></v-icon>
            </v-list-item-icon>
            <v-list-item-content>
              <v-list-item-title class="c-default" v-text="l.title"></v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list-item-group>
      </v-list>
    </v-navigation-drawer>

    <v-app-bar app class="adblack">
      <v-app-bar-nav-icon icon="mdi-sort-variant" color="pink darken-1" @click.stop="drawer = !drawer" />
      <!-- <v-text-field
        v-model="srch"
        append-icon="search"
        label="Search"
        single-line
        hide-details
      ></v-text-field> -->
      <v-toolbar-title class="c-default">{{ $route.name }}</v-toolbar-title>
      <v-spacer></v-spacer>

    </v-app-bar>

    

    <v-content>
      <v-sheet id="dark-custom" light min-height="100%" :class="['ct-wrap']">
        <v-container>
          <router-view />
        </v-container>
      </v-sheet>
<!--       <v-footer color="error" dark>
        <span class="white--text">&copy; 2019</span>
      </v-footer> -->
    </v-content>
  </v-app>
</template>

<script>

export default {
  props: {
    source: String
  },
  data() {
    return {
      drawer: null,
      srch:'',
      active: 0,
      navigation: [
        {
          title: "Dashboard",
          icon: "mdi-monitor-dashboard",
          action: "/dashboard"
        },
        {
          title: "User",
          icon: "mdi-format-list-bulleted",
          action: "/user"
        },
        {
          title: "Keluar",
          icon: "mdi-logout",
          action: "/logout"
        }
      ]
    };
  },

  computed: {
    profile() {
      return this.$store.state.user.userData;
    }
  },

  mounted() {
  },

  methods: {
    
  }
};
</script>
