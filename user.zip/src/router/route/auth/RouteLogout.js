const RouteLogout = {
    routes: [
        {
            path: '/logout',
            name: 'LayoutLogout',
            component: () => import("@/views/auth/LayoutLogout"),
            meta: {
                title: 'Logout'
            }
        }
    ]
}

export default RouteLogout