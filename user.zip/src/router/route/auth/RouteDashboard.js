const RouteDashboard = {
  routes: [
    {
      path: '/dashboard',
      name: 'Dashboard',
      component: () => import("@/views/auth/LayoutDashboard"),
      meta: {
        title: 'Dashboard'
      }
    },
    {
      path: '/user',
      name: 'User',
      component: () => import("@/views/auth/user/ListUser"),
      meta: {
        title: 'List User'
      }
    },
    {
      path: '/user/create',
      name: 'Add User',
      component: () => import("@/views/auth/user/CreateUser"),
      meta: {
        title: 'Add User'
      }
    },
    {
      path: '/user/edit/:id',
      name: 'Edit User',
      component: () => import("@/views/auth/user/EditUser"),
      meta: {
        title: 'Edit User'
      }
    }
  ]
}

export default RouteDashboard