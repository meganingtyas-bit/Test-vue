const RouteRegister = {
  routes: [
    {
      path: '/register',
      name: 'Register',
      component: () => import("@/views/unauth/LayoutRegister"),
      meta: {
        title: 'Register Admin'
      }
    }
  ]
}

export default RouteRegister