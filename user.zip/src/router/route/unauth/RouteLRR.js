const RouteLogin = {
	routes: [
		{
			path: "/",
			name: "LoginHome",
			component: () => import("@/views/unauth/LayoutLogin"),
			meta: {
				title: "Login User"
			}
		},
		{
			path: "/login",
			name: "Login",
			component: () => import("@/views/unauth/LayoutLogin"),
			meta: {
				title: "Login User"
			}
		}
		,
		{
			path: "/register",
			name: "Register",
			component: () => import("@/views/unauth/LayoutRegister"),
			meta: {
				title: "Register"
			}
		},
		// {
		// 	path: "/reset",
		// 	name: "Reset",
		// 	component: () => import("@/views/unauth/LayoutReset"),
		// 	meta: {
		// 		title: "Reset Admin"
		// 	}
		// },
		// {
		// 	path: "/verification",
		// 	name: "Verification",
		// 	component: () => import("@/views/unauth/LayoutVerification"),
		// 	meta: {
		// 		title: "Verification Admin"
		// 	}
		// }
	]
};

export default RouteLogin;
