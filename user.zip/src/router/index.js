import Vue from "vue";
import Router from "vue-router";
import RouteRegisterConfig from "../system/RouteRegisterConfig";
import StoreInit from "../system/lib/StoreInit";
const vueconfig = require("../../config");

import store from "@/store";

Vue.use(Router);

/* import file template */
import TemplateError404 from "../components/template/TemplateError404.vue";

/* base template */
import TemplateDefault from "../components/template/TemplateDefault.vue";
import TemplateLRR from "../components/template/TemplateLRR.vue";
import TemplateBlank from "../components/template/TemplateBlank.vue";

/* unauth */
import RouteLRR from "./route/unauth/RouteLRR";
RouteRegisterConfig.add(RouteLRR, TemplateLRR);

/* auth */
import RouteLogout from "./route/auth/RouteLogout";
import RouteDashboard from "./route/auth/RouteDashboard";
// import RouteUser from "./route/auth/RouteUser";

/* register template */
RouteRegisterConfig.add(RouteLogout, TemplateBlank, { isAuth: true });
RouteRegisterConfig.add(RouteDashboard, TemplateDefault, { isAuth: true });
// RouteRegisterConfig.add(RouteUser, TemplateDefault, { isAuth: true });

/* Default Route */
RouteRegisterConfig.add(
	{
		routes: [
			{
				path: "*",
				meta: { title: "Page Not Found 404" }
			}
		]
	},
	TemplateError404
);

/* register routes list to vue router */
let routeConf = {
	mode: "history",
	routes: RouteRegisterConfig.getList()
};

const isProduction = process.env.NODE_ENV === "production";

if (isProduction) {
	routeConf.base = vueconfig.routePath;
} else {
	routeConf.base = "/";
}

const router = new Router(routeConf);

let authRoute = {
	logedinDisable: ["login", "register"]
};
router.beforeEach((to, from, next) => {
	let nPath = to.path.substring(1);
	let arrPath = to.path.split("/");

	document.title = to.meta.title;

	// jika tidak login
		console.log(store.state.user);
	if (to.meta.isAuth === true && store.state.user.logedIn === false) {
		next({ path: "/login" });
		return;
	}

	if (store.state.user.logedIn === true) {
		if (authRoute.logedinDisable.includes(nPath) === true) {
			next({ path: "/dashboard" });
			return;
		}
	}

	next();
});

export default router;
