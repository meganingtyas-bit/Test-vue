const configdev = {
    // build dir created after npm run build
    buildDir: 'app',
  
    // jika domain sesuaikan urldomain jika localhost sesuaikan folder http://localhost/
    ciUrl: 'http://localhost/administrator',
  
    // routePath merupakan url path ci dimana index.html dijalankan untuk router vue
    routePath: '/administrator',
    baseUrl: 'http://localhost:8080',
    apiBaseUrl: 'https://reqres.in/api',
    fetch: {
      headers: {
        
      }
    }
  
  }
  
  const configlive = {
    // build dir created after npm run build
    buildDir: 'app',
    // jika domain sesuaikan urldomain jika localhost sesuaikan folder http://localhost/
    ciUrl: '',
  
    // routePath merupakan url path ci dimana index.html dijalankan untuk router vue
    routePath: '/',
    baseUrl: '',
    apiBaseUrl: 'https://reqres.in/api/',
  }
  module.exports = configdev
  // building live app
  // module.exports = Object.assign({}, configdev, configlive)