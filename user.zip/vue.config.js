const path = require('path')
const config = require('./config')

const HOST = process.env.HOST
const PORT = process.env.PORT && Number(process.env.PORT)

let conf = () => {
	if (process.env.NODE_ENV === 'production') {

		return {
			publicPath: config.ciUrl,
			buildDir: '/' + config.buildDir,
			proxyBaseUrl: '',

		}

	} else {
		return {
			publicPath: '/',
			buildDir: '',
			proxyBaseUrl: config.ciUrl,
		}

	}
}


module.exports = {
	"transpileDependencies": [
		"vuetify"
	],
	publicPath: conf().publicPath + conf().buildDir,
	outputDir: path.resolve(__dirname, '../' + conf().buildDir),
	devServer: {
		proxy: {
			'/api': {
				target: conf().proxyBaseUrl + '/api',
				changeOrigin: true,
				pathRewrite: {
					'^/api': ''
				}
			}
		}
	},
	pwa: {
		// name: "Vue Persistence",
		// themeColor: "#4DBA87",
		// msTileColor: "#000000",
		// appleMobileWebAppCapable: "yes",
		// appleMobileWebAppStatusBarStyle: "black",
		workboxPluginMode: "InjectManifest",
		workboxOptions: {
			swSrc: "src/service-worker.js"
		}
	},
}
